package Program11to15;

public class Methodoverriding1 {
	int speedlimit = 98;

	void abc() {
		System.out.println("child class");
	}


}
