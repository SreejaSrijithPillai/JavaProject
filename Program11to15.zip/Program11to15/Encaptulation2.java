package Program11to15;

public class Encaptulation2 {
	public static void main(String[] args) {
		Encaptulation1 en= new Encaptulation1();
		
		en.setName("nilesh");
		System.out.println(en.getName());
	}



}
