package Program11to15;

public class Methodoverriding2 extends Methodoverriding1 {

	int speedlimit = 120;

	void abc() {
		System.out.println("extended class ");
	}

	void cde() {

		System.out.println("speed limit");
		System.out.println(super.speedlimit);
	}

	public static void main(String[] args) {
		Methodoverriding1 rr = new Methodoverriding2(); // dynamic method dispatch
		System.out.println(rr.speedlimit);
		rr.abc();
		System.out.println("-------dynamic method dispatch----------");

		Methodoverriding2 re = new Methodoverriding2();
		System.out.println(re.speedlimit);
		// re.abc();
		re.cde();
	}

}

